from setuptools import setup
setup(name='multiplyNums',version='0.1',description='This is a package to multiply 2 numbers',
long_description="This is a package takes 2 numbers params ans gives the product of those 2 numbers",author="Roshni",
packages=['multiplyNums'],install_requires=[])